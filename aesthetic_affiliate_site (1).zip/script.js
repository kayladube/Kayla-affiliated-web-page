
// simple interactive animations placeholder
console.log('site loaded');
